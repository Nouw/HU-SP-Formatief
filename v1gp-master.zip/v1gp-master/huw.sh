#!/bin/sh
export FLASK_APP=huw.py
python -m flask run